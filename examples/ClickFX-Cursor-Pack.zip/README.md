# ClickFX 光标包

三个光标集，**每个都自带点击特效动画**（不是内置样式的换色，是包自己的一条帧带）。
切成不同的集合，光标和点击特效一起换。

| 集合 | 配色 | 点击特效 | 帧带 |
|------|------|----------|------|
| `ClickFX Gold Ripple` | 金 | 波纹扩散 + 淡出 | `gold/click/ripple.png`（8 帧 × 45ms） |
| `ClickFX Blue Burst` | 蓝 | 粒子向外爆开 | `blue/click/burst.png`（8 帧 × 40ms） |
| `ClickFX Pink Pulse` | 粉 | 实心点放大淡出 | `pink/click/pulse.png`（8 帧 × 55ms） |

| 状态 | 素材 | 说明 |
|------|------|------|
| `default` | `<配色>/arrow.png` | 箭头，白身 + 配色尖端，热点 1,1 |
| `clickable` | `<配色>/arrow_click.png` | 整支变成配色，一眼能看出按到了 |
| `text` | `<配色>/ibeam.png` | I 型文本光标，热点 16,16 |
| `busy` | `<配色>/busy.png` | 8 帧旋转点，热点 16,16 |

## 安装

- **光标包方式**：把 `ClickFX-Cursor-Pack.zip`（或解压后的文件夹）丢进 `config/cursorkit/packs/`，
  或者直接**拖进光标选择界面**；不需要开资源包界面
- **资源包方式**：放进 `resourcepacks/` 也行，文件布局完全一样

## 特效是怎么定义的

```json
"click_effect": {
    "type": "image",
    "texture": "gold/click/ripple.png",
    "frames": 8,
    "frame_ms": 45,
    "size": 48
}
```

`texture` 相对 `textures/cursor/`，其余含义见模组 README 的「点击特效」一节。
帧图里的淡出是**画进图里**的：贴图绘制不能整体调透明度。
把 `type` 换成 `ripple` / `burst` / `pulse` / `none` 就能在"用内置样式"和"用自带动画"之间切换。
